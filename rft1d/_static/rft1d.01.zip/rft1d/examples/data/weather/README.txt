This dataset was made available by Prof. James O. Ramsay
of McGill University. The dataset was download from:
http://www.psych.mcgill.ca/misc/fda/downloads/FDAfuns/Matlab
on 16 August 2014 (the “weather.zip” file).

No license was found with that dataset. Only "daily.m" and
"daily.mat" from that dataset are redistributed here, on
the condition that the original source be acknowledged.

The dataset is described here:
http://www.psych.mcgill.ca/misc/fda/ex-weather-a1.html
... and also in:
Ramsay JO, Silverman BW (2005). Functional Data Analysis
(Second Edition), Springer, New York.
Chapter 13: "Modelling functional responses with
multivariate covariates"