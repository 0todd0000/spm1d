
import os
import numpy as np
from scipy.io import loadmat
from scipy.ndimage.filters import gaussian_filter1d
from matplotlib import pyplot



#(0) Load data and geographical indices:
dir0     = os.path.dirname(__file__)
fname    = os.path.join(dir0, 'data', 'weather', 'daily.mat')
M        = loadmat(fname)
Y        = M['tempav'].T
geogind  = M['geogindex'].flatten()
### smooth:
Y        = gaussian_filter1d(Y, 8.0, axis=1, mode='wrap')
### place indices (from daily.m, Lines 412-415)
atlindex = [1,2,4,8,9,13,14,15,19,22,23,24,25,28,34]
pacindex = [12,17,18,30,31]
conindex = [3,5,6,7,16,20,26,27,29,32,33,35]
artindex = [10,11,21]
### boolean indices for places:
i0       = np.array([i in atlindex for i in geogind])
i1       = np.array([i in pacindex for i in geogind])
i2       = np.array([i in conindex for i in geogind])
i3       = np.array([i in artindex for i in geogind])
### extract places:
y0       = Y[i0]
y1       = Y[i1]
y2       = Y[i2]
y3       = Y[i3]




#(1) Plot:
pyplot.close('all')
labels = ['Atlantic', 'Pacific', 'Continental', 'Artic']
colors = ['r', 'g', 'b', 'k']
ax     = pyplot.axes()
for y,color,label in zip((y0,y1,y2,y3), colors, labels):
	h  = ax.plot(y.T, color=color)
	h[0].set_label(label)
ax.set_xlabel('Day', size=16)
ax.set_ylabel('Temperature', size=16)
ax.legend()
ax.set_title('Weather dataset (Ramsay et al. 2005)', size=20)
pyplot.show()










