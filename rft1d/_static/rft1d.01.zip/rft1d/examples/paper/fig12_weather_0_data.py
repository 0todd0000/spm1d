
import os
import numpy as np
from scipy.io import loadmat
from scipy.ndimage.filters import gaussian_filter1d
from matplotlib import pyplot






### EPS production preliminaries:
fig_width_mm  = 100
fig_height_mm = 80
mm2in = 1/25.4
fig_width  = fig_width_mm*mm2in  	# width in inches
fig_height = fig_height_mm*mm2in    # height in inches
params = {	'backend':'ps', 'axes.labelsize':14,
			'text.fontsize':12, 'text.usetex': False, 'legend.fontsize':12,
			'xtick.labelsize':8, 'ytick.labelsize':8,
			'font.family':'Times New Roman',  #Times
			'lines.linewidth':0.5,
			'patch.linewidth':0.25,
			'figure.figsize': [fig_width,fig_height]}
pyplot.rcParams.update(params)




#(0) Load data and geographical indices:
dir0     = os.path.dirname(__file__)
fname    = os.path.join(dir0, 'data', 'weather', 'daily.mat')
M        = loadmat(fname)
Y        = M['tempav'].T
geogind  = M['geogindex'].flatten()
### smooth:
Y        = gaussian_filter1d(Y, 8.0, axis=1, mode='wrap')
### place indices (from daily.m, Lines 412-415)
atlindex = [1,2,4,8,9,13,14,15,19,22,23,24,25,28,34]
pacindex = [12,17,18,30,31]
conindex = [3,5,6,7,16,20,26,27,29,32,33,35]
artindex = [10,11,21]
### boolean indices for places:
i0       = np.array([i in atlindex for i in geogind])
i1       = np.array([i in pacindex for i in geogind])
i2       = np.array([i in conindex for i in geogind])
i3       = np.array([i in artindex for i in geogind])
### extract places:
y0       = Y[i0]
y1       = Y[i1]
y2       = Y[i2]
y3       = Y[i3]




#(1) Plot:
pyplot.close('all')
labels = ['Atlantic', 'Pacific', 'Continental', 'Artic']
colors = ['r', 'g', 'b', 'k']
ax     = pyplot.axes([0.13,0.15,0.84,0.83])
for y,color,label in zip((y0,y1,y2,y3), colors, labels):
	h  = ax.plot(y.T, color=color)
	h[0].set_label(label)
ax.legend(loc='lower center')
ax.set_xlabel('Day', size=16)
ax.set_ylabel('Temperature', size=16)
ax.set_ylim(-45, 25)
pyplot.show()



# pyplot.savefig('fig_weather_0_data.pdf')


