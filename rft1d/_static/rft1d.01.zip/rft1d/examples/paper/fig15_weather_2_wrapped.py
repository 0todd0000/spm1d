
import os
import numpy as np
from scipy.io import loadmat
from scipy.ndimage.filters import gaussian_filter1d
from matplotlib import pyplot
import rft1d





### EPS production preliminaries:
fig_width_mm  = 100
fig_height_mm = 80
mm2in = 1/25.4
fig_width  = fig_width_mm*mm2in  	# width in inches
fig_height = fig_height_mm*mm2in    # height in inches
params = {	'backend':'ps', 'axes.labelsize':14,
			'text.fontsize':12, 'text.usetex': False, 'legend.fontsize':12,
			'xtick.labelsize':8, 'ytick.labelsize':8,
			'font.family':'Times New Roman',  #Times
			'lines.linewidth':0.5,
			'patch.linewidth':0.25,
			'figure.figsize': [fig_width,fig_height]}
pyplot.rcParams.update(params)




#(0) Load data and geographical indices:
dir0     = os.path.dirname(__file__)
fname    = os.path.join(dir0, 'data', 'weather', 'daily.mat')
M        = loadmat(fname)
Y        = M['tempav'].T
geogind  = M['geogindex'].flatten()
### smooth:
Y        = gaussian_filter1d(Y, 8.0, axis=1, mode='wrap')
### place indices (from daily.m, Lines 412-415)
atlindex = [1,2,4,8,9,13,14,15,19,22,23,24,25,28,34] #Atlantic
pacindex = [12,17,18,30,31] #Pacific
conindex = [3,5,6,7,16,20,26,27,29,32,33,35] #Continental
artindex = [10,11,21] #Arctic
### boolean indices for places:
i0       = np.array([i in atlindex for i in geogind])
i1       = np.array([i in pacindex for i in geogind])
i2       = np.array([i in conindex for i in geogind])
i3       = np.array([i in artindex for i in geogind])
### extract places:
y0       = Y[i0]
y1       = Y[i1]
y2       = Y[i2]
y3       = Y[i3]




#(1) Two-sample t statistic (comparing just the two largest groups):
yA,yB    = y0,y2  #Atlantic and Contintental
nA,nB    = yA.shape[0], yB.shape[0]  #sample sizes
mA,mB    = yA.mean(axis=0), yB.mean(axis=0)  #means
sA,sB    = yA.std(ddof=1, axis=0), yB.std(ddof=1, axis=0)  #standard deviations
s        = np.sqrt(    ((nA-1)*sA*sA + (nB-1)*sB*sB)  /  (nA + nB - 2)     )  #pooled standard deviation
t        = (mA-mB) / ( s *np.sqrt(1.0/nA + 1.0/nB))  #t field




#(2) Estimate field smoothness:
rA,rB    = yA-mA, yB-mB  #residuals
r        = np.vstack([rA,rB])
FWHM     = rft1d.geom.estimate_fwhm(r)



#(3) Critical threshold (classical hypothesis testing):
alpha    = 0.05
df       = nA + nB - 2  #degrees of freedom
Q        = Y.shape[1]  #number of nodes (field length = Q-1)
tstar    = rft1d.t.isf(alpha, df, Q, FWHM) #inverse survival function



#(4) Get upcrossing metrics:
calc      = rft1d.geom.ClusterMetricCalculator()
k         = calc.cluster_extents(t, tstar, interp=True)
k         = sum(k) / FWHM  #wrapped into a single upcrossing
nClusters = 1




#(5) Probabilities:
rftcalc  = rft1d.prob.RFTCalculator(STAT='T', df=(1,df), nodes=Q, FWHM=FWHM)
Pset     = rftcalc.p.set(nClusters, k, tstar)
Pcluster = rftcalc.p.cluster(k, tstar)




#(6) Plot:
pyplot.close('all')
ax     = pyplot.axes([0.08,0.15,0.89,0.83])
ax.plot(t, 'k', lw=3, label='t field')
ax.plot([0,Q], [tstar]*2, 'r--', label='Critical threshold')
### legend:
ax.legend(loc='upper left')
### cluster p value:
ax.text(120, 4.0,  'p = %.6f'%Pcluster)
ax.plot([30,110], [3,4], 'k:')
ax.plot([190,310], [4,3.5], 'k:')
ax.plot([30,310], [3,3.5], 'ko')
ax.text(280, 2.1, r'$\alpha$ = %.3f'%alpha, color='r')
### axis labels:
ax.set_xlabel('Day', size=16)
ax.set_ylabel('t value', size=16)
pyplot.show()



# pyplot.savefig('fig_weather_2_wrapped.pdf')


