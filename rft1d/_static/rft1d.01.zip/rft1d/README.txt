________________________________________________________________________

Documentation

Full documentation for rft1d is attached in HTML format.


________________________________________________________________________

Disclaimer

rft1d is free but copyright software, distributed under the terms of the GNU General Public License as published by the Free Software Foundation (version 3, as below). Further details on "copyleft" can be found at http://www.gnu.org/copyleft/. In particular, SPM is supplied as is. No formal support or maintenance is provided or implied.

rft1d is currently developed and maintained by Todd Pataky.


 
________________________________________________________________________

License Information

rft1d is a package implementing one-dimensional Random Field Theory (RFT).

    Copyright (C) 2014  Todd Pataky

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

